<?php
$flaticons_custom = array(
    array( 'flaticon-custom-arrows' => 'flaticon-custom-arrows' ),
    array( 'flaticon-custom-commerce' => 'flaticon-custom-commerce' ),
    array( 'flaticon-custom-graphic' => 'flaticon-custom-graphic' ),
    array( 'flaticon-custom-graphic-1' => 'flaticon-custom-graphic-1' ),
    array( 'flaticon-custom-handshake' => 'flaticon-custom-handshake' ),
    array( 'flaticon-custom-headphones' => 'flaticon-custom-headphones' ),
    array( 'flaticon-custom-interface' => 'flaticon-custom-interface' ),
    array( 'flaticon-custom-layers' => 'flaticon-custom-layers' ),
    array( 'flaticon-custom-light-bulb' => 'flaticon-custom-light-bulb' ),
    array( 'flaticon-custom-mail' => 'flaticon-custom-mail' ),
    array( 'flaticon-custom-share' => 'flaticon-custom-share' ),
    array( 'flaticon-custom-target' => 'flaticon-custom-target' ),
    array( 'flaticon-custom-text-on-paper-sheet-sketch' => 'flaticon-custom-text-on-paper-sheet-sketch' ),
);