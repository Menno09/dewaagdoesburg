<?php
$flaticons_redchili = array(
    array( 'flaticon-redchili-coffee-cup' => 'flaticon-redchili-coffee-cup' ),
    array( 'flaticon-redchili-cooker' => 'flaticon-redchili-cooker' ),
    array( 'flaticon-redchili-cup' => 'flaticon-redchili-cup' ),
    array( 'flaticon-redchili-cupcake' => 'flaticon-redchili-cupcake' ),
    array( 'flaticon-redchili-food' => 'flaticon-redchili-food' ),
    array( 'flaticon-redchili-hamburger' => 'flaticon-redchili-hamburger' ),
    array( 'flaticon-redchili-pizza' => 'flaticon-redchili-pizza' ),
    array( 'flaticon-redchili-restaurant' => 'flaticon-redchili-restaurant' ),
    array( 'flaticon-redchili-verified-protection' => 'flaticon-redchili-verified-protection' ),
);